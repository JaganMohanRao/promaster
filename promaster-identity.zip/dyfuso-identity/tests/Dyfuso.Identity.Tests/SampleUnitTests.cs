using System;
using Xunit;

namespace Dyfuso.Identity.Tests
{
    public class SampleUnitTests
    {
        [Fact]
        public void BuildCheck_WhenTrue_BuildWorks()
        {
        }
    }
}
