﻿using Dyfuso.Identity.Data;
using Dyfuso.Identity.Models;
using IdentityModel;
using IdentityServer4.EntityFramework.DbContexts;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;
using System;
using System.Linq;
using System.Security.Claims;

namespace Dyfuso.Identity
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var host = CreateWebHostBuilder(args).Build();

            using (var scope = host.Services.CreateScope())
            {
                var service = scope.ServiceProvider;

                var configuration = host.Services.GetRequiredService<IConfiguration>();
                var useTestData = configuration.GetValue("UseTestData", true);
                var adminPassword = configuration.GetValue("AdminPassword", "");

                CreateDbIfNotExists(service);
                CreateUserandRolesIfNotExists(service, useTestData, adminPassword);
            }

            host.Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args)
        {
            return WebHost.CreateDefaultBuilder(args)
                    .UseStartup<Startup>()
                    .UseSerilog((context, configuration) =>
                    {
                        configuration
                            .MinimumLevel.Debug()
                            .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                            .MinimumLevel.Override("System", LogEventLevel.Warning)
                            .MinimumLevel.Override("Microsoft.AspNetCore.Authentication", LogEventLevel.Information)
                            .Enrich.FromLogContext()
                            .WriteTo.Console();
                    });
        }

        private static void CreateDbIfNotExists(IServiceProvider services)
        {
            try
            {
                services.GetRequiredService<ApplicationDbContext>().Database.Migrate();
                services.GetRequiredService<PersistedGrantDbContext>().Database.Migrate();
            }
            catch (Exception ex)
            {
                var logger = services.GetRequiredService<ILogger<Program>>();
                logger.LogError(ex, "An error occurred creating the DB.");
            }
        }

        private static void CreateRoleIfNotExists(RoleManager<IdentityRole> roleMgr, string roleName)
        {
            var role = roleMgr.FindByNameAsync(roleName).Result;

            if (role == null)
            {
                var roleResult = roleMgr.CreateAsync(new IdentityRole(roleName)).Result;

                if (!roleResult.Succeeded)
                {
                    throw new Exception(roleResult.Errors.First().Description);
                }
            }
        }

        private static void CreateUserIfNotExists(UserManager<ApplicationUser> usrMgr, ApplicationUser appUser, string password, string role)
        {
            // Check if the user exists           
            var user = usrMgr.FindByNameAsync(appUser.UserName).Result;

            if (user == null)
            {
                var result = usrMgr.CreateAsync(appUser, password).Result;

                if (!result.Succeeded)
                {
                    throw new Exception(result.Errors.First().Description);
                }

                result = usrMgr.AddClaimsAsync(appUser, new Claim[]{
                    new Claim("title_id", appUser.TitleId.ToString()),
                    new Claim(JwtClaimTypes.Name, appUser.FullName),
                    new Claim(JwtClaimTypes.GivenName, appUser.Forename),
                    new Claim(JwtClaimTypes.FamilyName, appUser.Surname),
                    new Claim(JwtClaimTypes.Email, appUser.Email),
                    new Claim(JwtClaimTypes.EmailVerified, "true", ClaimValueTypes.Boolean),
                    //new Claim(JwtClaimTypes.Address, @"{ 'street_address': 'One Hacker Way', 'locality': 'Heidelberg', 'postal_code': 69118, 'country': 'Germany' }", IdentityServer4.IdentityServerConstants.ClaimValueTypes.Json)
                }).Result;

                if (!result.Succeeded)
                {
                    throw new Exception(result.Errors.First().Description);
                }

                var roleResult = usrMgr.AddToRoleAsync(appUser, role).Result;

                if (!roleResult.Succeeded)
                {
                    throw new Exception(roleResult.Errors.First().Description);
                }

            }
        }

        private static void CreateUserandRolesIfNotExists(IServiceProvider services, bool useTestData, string adminPassword)
        {
            // TODO - remove the roles as they are not needed

            var userMgr = services.GetRequiredService<UserManager<ApplicationUser>>();
            var roleMgr = services.GetRequiredService<RoleManager<IdentityRole>>();

            CreateRoleIfNotExists(roleMgr, "admin"); // dyfuso admin
            CreateUserIfNotExists(userMgr, new ApplicationUser(1, "admin@dyfuso.com", "Test", "Admin"), adminPassword, "admin");

            if (useTestData)
            {
                CreateRoleIfNotExists(roleMgr, "debug"); // Debug
                CreateUserIfNotExists(userMgr, new ApplicationUser(1, "debug@dyfuso.com", "Debug", "User"), "P455w0rd1!", "debug");

                CreateRoleIfNotExists(roleMgr, "admin"); //
                CreateUserIfNotExists(userMgr, new ApplicationUser(1, "gary.chalmers@springfield.com", "Gary", "Chalmers"), "P455w0rd1!", "admin");

                CreateRoleIfNotExists(roleMgr, "org-admin"); // organisation admin
                CreateUserIfNotExists(userMgr, new ApplicationUser(1, "seymour.skinner@springfield.com", "Seymour", "Skinner"), "P455w0rd1!", "org-admin");

                CreateRoleIfNotExists(roleMgr, "parent"); // parent
                CreateUserIfNotExists(userMgr, new ApplicationUser(1, "homer.simpson@springfield.com", "Homer", "Simpson"), "P455w0rd1!", "parent");
                CreateUserIfNotExists(userMgr, new ApplicationUser(2, "marge.simpson@springfield.com", "Marge", "Simpson"), "P455w0rd1!", "parent");

                CreateRoleIfNotExists(roleMgr, "teacher"); // teacher
                CreateUserIfNotExists(userMgr, new ApplicationUser(4, "edna.krabappel@springfield.com", "Edna", "Krabappel"), "P455w0rd1!", "teacher");
                CreateUserIfNotExists(userMgr, new ApplicationUser(2, "elizabeth.hoover@springfield.com", "Elizabeth", "Hoover"), "P455w0rd1!", "teacher");

                CreateRoleIfNotExists(roleMgr, "student"); // student
                CreateUserIfNotExists(userMgr, new ApplicationUser(5, "bart.simpson@springfield.com", "Bart", "Simpson"), "P455w0rd1!", "student");
                CreateUserIfNotExists(userMgr, new ApplicationUser(3, "lisa.simpson@springfield.com", "Lisa", "Simpson"), "P455w0rd1!", "student");

                // Test music teacher
                CreateUserIfNotExists(userMgr, new ApplicationUser(1, "dewey.largo@springfield.com", "Dewey", "Largo"), "P455w0rd1!", "teacher");
            }
        }
    }
}
