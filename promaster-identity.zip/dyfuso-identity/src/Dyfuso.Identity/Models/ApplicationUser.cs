﻿using Microsoft.AspNetCore.Identity;

namespace Dyfuso.Identity.Models
{
    public class ApplicationUser : IdentityUser
    {
        public ApplicationUser() { }

        public ApplicationUser(int titleId, string userName, string forename, string surname)
        {
            TitleId = titleId;
            UserName = userName.ToLower();
            Forename = forename;
            Surname = surname;
            Email = userName.ToLower();
        }

        public int TitleId { get; set; }
        public string Forename { get; set; }
        public string Surname { get; set; }
        public string FullName => string.Format("{0} {1}", Forename, Surname);
    }
}
