﻿using Dyfuso.Identity.Data;
using Dyfuso.Identity.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using StackExchange.Redis;
using System;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;

namespace Dyfuso.Identity
{
    public class Startup
    {
        private readonly string _mvcResponseUri;
        private readonly string _baseUri;
        private readonly string _redisConnectionString;
        private readonly string _identityContext;
        private readonly string _sharedKey;

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;

            _mvcResponseUri = Configuration.GetValue("MvcResponseUri", "");
            _baseUri = Configuration.GetValue("BaseUri", "");
            _redisConnectionString = Configuration.GetConnectionString("RedisConnectionString");
            _sharedKey = Configuration.GetValue("SharedKey", "");
            _identityContext = Configuration.GetConnectionString("IdentityContext");
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            //TODO remove this
            Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII = true;

            services.AddControllersWithViews();

            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseNpgsql(_identityContext));

            services.AddIdentity<ApplicationUser, IdentityRole>()
                    .AddEntityFrameworkStores<ApplicationDbContext>()
                    .AddDefaultTokenProviders();

            var redis = ConnectionMultiplexer.Connect(_redisConnectionString);
            services.AddDataProtection()
                    .PersistKeysToStackExchangeRedis(redis, "dyfuso-identity-protection");

            var migrationsAssembly = typeof(Startup).GetTypeInfo().Assembly.GetName().Name;

            var builder = services.AddIdentityServer(options =>
            {
                options.PublicOrigin = _baseUri;
                options.Events.RaiseErrorEvents = true;
                options.Events.RaiseInformationEvents = true;
                options.Events.RaiseFailureEvents = true;
                options.Events.RaiseSuccessEvents = true;
            })
            .AddOperationalStore(options =>
            {
                options.ConfigureDbContext = b => b.UseNpgsql(_identityContext,
                    sql => sql.MigrationsAssembly(migrationsAssembly));
            });

            builder.AddInMemoryIdentityResources(Config.Ids);
            builder.AddInMemoryApiResources(Config.Apis);
            builder.AddInMemoryClients(Config.Clients(_mvcResponseUri));
            builder.AddAspNetIdentity<ApplicationUser>();
            builder.AddProfileService<IdentityProfileService>();


            var sharedKey = Convert.FromBase64String(_sharedKey);
            var certificate = new X509Certificate2(sharedKey, "password");
            builder.AddSigningCredential(certificate);

            /*
                    .AddGoogle("Google", options =>
                    {
                        options.SignInScheme = IdentityServerConstants.ExternalCookieAuthenticationScheme;

                        options.ClientId = "<insert here>";
                        options.ClientSecret = "<insert here>";
                    });
            */
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILogger<Startup> logger)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            logger.LogInformation("MvcResponseUri: {0}", _mvcResponseUri);

            app.UseStaticFiles();
            app.UseRouting();

            app.UseIdentityServer();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapDefaultControllerRoute();
            });
        }
    }
}