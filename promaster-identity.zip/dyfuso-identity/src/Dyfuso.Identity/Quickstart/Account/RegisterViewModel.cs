﻿using Microsoft.AspNetCore.Authentication;
using System.Collections.Generic;

namespace Dyfuso.Identity
{
    public class RegisterViewModel
    {
        public RegisterInputModel Input { get; set; } = new RegisterInputModel();

        public string ReturnUrl { get; set; }

        public IList<AuthenticationScheme> ExternalLogins { get; set; }
    }
}