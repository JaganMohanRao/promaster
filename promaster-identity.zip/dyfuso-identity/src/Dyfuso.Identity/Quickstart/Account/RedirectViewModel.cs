namespace Dyfuso.Identity
{
    public class RedirectViewModel
    {
        public string RedirectUrl { get; set; }
    }
}