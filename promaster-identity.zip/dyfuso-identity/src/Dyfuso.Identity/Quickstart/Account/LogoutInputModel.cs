﻿namespace Dyfuso.Identity
{
    public class LogoutInputModel
    {
        public string LogoutId { get; set; }
    }
}
