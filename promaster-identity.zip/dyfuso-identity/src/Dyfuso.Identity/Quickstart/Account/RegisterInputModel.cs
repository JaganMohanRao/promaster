﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Dyfuso.Identity
{
    public class RegisterInputModel
    {
        private readonly List<SelectListItem> _titles;

        public RegisterInputModel()
        {
            _titles = new List<SelectListItem>()
            {
                new SelectListItem("Mr", "1"),
                new SelectListItem("Mrs", "2"),
                new SelectListItem("Miss", "3"),
                new SelectListItem("Ms", "4"),
                new SelectListItem("Master", "5")
            };
        }

        public IEnumerable<SelectListItem> Titles
        {
            get { return _titles; }
        }

        [Required]
        [Display(Name = "Title")]
        public int TitleId { get; set; }

        [Required]
        [Display(Name = "Forename")]
        [RegularExpression(@"^[a-zA-z'-]+([\s][a-zA-Z'-])*$", ErrorMessage = "Invalid Forename")]
        public string Forename { get; set; }

        [Required]
        [Display(Name = "Surname")]
        [RegularExpression(@"^[a-zA-z'-]+([\s][a-zA-Z'-]+)*$", ErrorMessage = "Invalid Surename")]
        public string Surname { get; set; }

        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        [RegularExpression(@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Invalid Email")]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        [RegularExpression(@"(?=^.{8,15}$)(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?!.*\s).*$", ErrorMessage = "Invalid Password, should contain 8 and 15 inclusive, contains atleast one digit, atleast one upper case and atleast one lower case and no whitespace. ")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }
}
