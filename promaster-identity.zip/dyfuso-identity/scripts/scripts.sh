#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

function ef-generate() {
    pushd src/Dyfuso.Identity > /dev/null

    echo "Removing old migrations"
    rm -rf Migrations/*

    echo "Generating new migrations"
    dotnet ef migrations add initial --context ApplicationDbContext    
    dotnet ef migrations add initialps --context PersistedGrantDbContext

    popd > /dev/null
}

function build() {
    echo 'Building'
    dotnet build 
}

function run() {
    pushd src/Dyfuso.Identity > /dev/null
    
    echo 'Starting'
    dotnet run 

    popd > /dev/null
}

function package() {
    echo "Building"
    docker build . --tag dyfuso-identity
}

function deploy() {
    helm upgrade -i dyfuso-identity helm/dyfuso-identity -f helm/dyfuso-identity/local-values.yaml
}

function down() {
    helm delete dyfuso-identity
}

$@

